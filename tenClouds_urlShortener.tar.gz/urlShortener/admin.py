from django.contrib import admin
from .models import random_users, user_urls

admin.site.register(random_users)
admin.site.register(user_urls)



